package ejercicio3;

public interface InstalacionDeportiva {
	int getTipoDeInstalacion();
}
