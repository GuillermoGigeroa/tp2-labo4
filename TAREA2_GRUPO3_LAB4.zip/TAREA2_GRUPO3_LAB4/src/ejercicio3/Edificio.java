package ejercicio3;

public interface Edificio {
	double getSuperficieEdificio();
}
